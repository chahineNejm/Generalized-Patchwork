"""Shared OISST comparison with explicit configuration and per-run artifacts."""

from __future__ import annotations

import gc
import importlib.metadata
import json
import os
import platform
import shutil
import time
import zipfile
from dataclasses import asdict, dataclass
from datetime import date
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", str(Path("results/.matplotlib").resolve()))

import faiss
import gpytorch
import matplotlib
import numpy as np
import torch
from tqdm.auto import tqdm

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from experiments.exploratory_analysis import (
    analyze_run,
    explore_dataset,
    plot_hyperparameters,
    plot_positions,
    plot_training,
)
from experiments.ukhousing_benchmark import UKConfig, build_model, scores, train
from pwgp.config import HyperparameterBounds, NumericalConfig, OptimizerConfig
from pwgp.data import DatasetManager
from pwgp.data.download import file_checksum
from pwgp.models.standard_patchwork import StandardPatchworkGP
from pwgp.run_records import record_failures


@dataclass(frozen=True)
class OISSTConfig:
    day: str
    bounds: tuple[float, float, float, float]
    seed: int
    train_fraction: float
    validation_fraction: float
    save_inducing_positions: bool


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False), encoding="utf-8")


def prepare_split(dataset, config):
    x, y = dataset.x, dataset.y
    west, east, south, north = config.bounds
    if not -180 <= west < east <= 0 or not -90 <= south < north <= 90:
        raise ValueError("This OISST protocol requires a western-hemisphere ROI with west < east")
    if not 0 < config.train_fraction < 1 or not 0 < config.validation_fraction < 1 - config.train_fraction:
        raise ValueError("Train/validation fractions must be positive and leave a nonempty test fraction")
    if x.shape != (len(y), 2) or not np.isfinite(x).all() or not np.isfinite(y).all():
        raise ValueError("OISST split requires finite x[N,2], y[N]")
    normalized = (x - [west % 360, south]) / [east - west, north - south]
    if (normalized <= 0).any() or (normalized >= 1).any():
        raise ValueError("OISST cell centers must lie strictly inside the declared ROI")
    indices = np.random.default_rng(config.seed).permutation(len(y))
    nt, nv = int(config.train_fraction * len(y)), int(config.validation_fraction * len(y))
    groups = {"train": indices[:nt], "validation": indices[nt:nt + nv], "test": indices[nt + nv:]}
    if any(len(rows) == 0 for rows in groups.values()):
        raise ValueError("Every OISST split must be nonempty")
    center, scale = float(y[groups["train"]].mean()), float(y[groups["train"]].std())
    if not np.isfinite(scale) or scale <= 0:
        raise ValueError("Training target SD must be finite and positive")
    return {**groups, "x": torch.from_numpy(normalized.astype(np.float64)),
            "y": torch.from_numpy((y.astype(np.float64) - center) / scale),
            "raw_x": x, "raw_y": y, "target_mean": center, "target_std": scale,
            "input_transform": "Longitude in [0,360); affine normalization using declared ROI",
            "target_transform": "Celsius standardized using training targets only"}


def acquire(config, *, data_root):
    manager = DatasetManager(data_root)
    with tqdm(total=3, desc="prepare:OISST", unit="stage") as progress:
        paths = manager.download("oisst", day=date.fromisoformat(config.day))
        progress.update()
        if len(paths) != 1:
            raise ValueError("OISST acquisition must produce exactly one daily file")
        dataset = manager.load("oisst", path=paths[0], bounds=config.bounds)
        progress.update()
        split = prepare_split(dataset, config)
        progress.update()
    manifest = {"acquisition": manager.manifest("oisst"), "day": config.day,
                "bounds": config.bounds, "sha256": file_checksum(paths[0]),
                "cleaning": dataset.metadata, "observations": len(dataset.y)}
    return split, manifest


@torch.no_grad()
def predict(model, x, *, batch_size):
    if batch_size < 1 or len(x) == 0:
        raise ValueError("Prediction requires positive batch size and nonempty inputs")
    device = next(model.parameters()).device
    model.eval()
    state = model.conditioned_state() if isinstance(model, StandardPatchworkGP) else None
    means, variances = [], []
    for batch in tqdm(x.split(batch_size), desc="predict", unit="batch", leave=False):
        options = {"state": state} if state is not None else {}
        mean, variance = model.predict(batch.to(device), observation_noise=True, **options)
        means.append(mean.cpu())
        variances.append(variance.cpu())
    return torch.cat(means).numpy(), torch.cat(variances).numpy()


def supports(model, kind):
    if kind == "patchwork":
        return None
    if kind == "vnngp":
        return model.variational_strategy.inducing_points.detach().cpu().numpy()[None]
    z = model.supports()
    z = torch.stack(z) if kind == "prospar" else z
    result = z.detach().cpu().numpy()
    return result[None] if result.ndim == 2 else result


def map_figure(coordinates, fields, *, destination):
    columns = min(len(fields), 4)
    rows = (len(fields) + columns - 1) // columns
    fig, axes = plt.subplots(rows, columns, figsize=(4 * columns, 4 * rows),
                             constrained_layout=True, squeeze=False)
    for ax, (title, values) in zip(axes.flat, fields.items(), strict=False):
        artist = ax.scatter(*coordinates.T, c=values, s=3, cmap="viridis")
        ax.set(title=title, xlabel="Longitude (0-360)", ylabel="Latitude")
        fig.colorbar(artist, ax=ax, shrink=0.7)
    for ax in list(axes.flat)[len(fields):]:
        ax.set_visible(False)
    fig.savefig(destination, dpi=140)
    plt.close(fig)


def learned_parameters(model, kind):
    if kind == "vnngp":
        return {"lengthscales": model.covar_module.base_kernel.lengthscale.detach().cpu().tolist(),
                "outputscales": [float(model.covar_module.outputscale.detach())],
                "noise_std": float(model.likelihood.noise.detach().sqrt().squeeze())}
    hyp = model.hyp
    learned = {"lengthscales": hyp.lengthscales().detach().cpu().tolist(),
               "outputscales": hyp.outputscales().detach().cpu().tolist(),
               "noise_std": float(hyp.noise_std().detach())}
    if kind == "prospar":
        learned.update(temperatures=hyp.temperatures().detach().cpu().tolist(),
                       exponent=float(hyp.exponent().detach()),
                       inducing_nuggets=[d.detach().cpu().tolist() for d in hyp.nuggets()],
                       prior_jitter=model.prior_jitter)
    return learned


def run_model(config, split, *, directory, save_inducing_positions, on_snapshot=None):
    output = Path(directory)
    output.mkdir(exist_ok=False)
    with record_failures(output, status_key="state"):
        write_json(output / "config.json", asdict(config))
        if config.epochs < 1:
            raise ValueError(f"{config.model}: epochs={config.epochs} must be positive")
        if config.model != "patchwork" and not 0 <= config.warmup_epochs < config.epochs:
            raise ValueError(f"{config.model}: require 0 <= warmup_epochs={config.warmup_epochs} "
                             f"< epochs={config.epochs}")
        if config.snapshot_every < 1:
            raise ValueError(f"{config.model}: snapshot_every={config.snapshot_every} must be positive")
        device = torch.device(config.device)
        if device.type == "cuda" and not torch.cuda.is_available():
            raise RuntimeError("Requested GPU is unavailable; no CPU fallback")
        torch.set_num_threads(config.threads)
        faiss.omp_set_num_threads(config.threads)
        torch.manual_seed(config.seed)
        np.random.seed(config.seed)
        if device.type == "cuda":
            torch.cuda.synchronize(device)
            torch.cuda.reset_peak_memory_stats(device)
        write_json(output / "environment.json", {
            "python": platform.python_version(), "platform": platform.platform(),
            "torch": torch.__version__, "gpytorch": gpytorch.__version__,
            "numpy": np.__version__, "cuda_runtime": torch.version.cuda,
            "faiss": importlib.metadata.version("faiss-cpu"), "dtype": "float64",
            "device": str(device), "threads": config.threads,
            "gpu": torch.cuda.get_device_name(device) if device.type == "cuda" else None,
            "bounds": asdict(HyperparameterBounds()),
            "numerical": asdict(NumericalConfig(weight_epsilon=config.weight_epsilon)),
            "fusion_covariance": "Cov(local_functions | U, Delta_S=0)" if config.model == "gpw" else None,
            "standard_patchwork_objective": "joint_negative_log_likelihood(Y, Delta_S=0)"
            if config.model == "patchwork" else None,
            "active_prior_jitter": config.prospar.prior_jitter if config.model == "prospar"
            and config.prospar is not None else NumericalConfig().prior_jitter,
            "optimizer": {"method": "Adam", "learning_rate": config.exact_learning_rate,
                          "gradient_clip": 10.0, "warmup": "not_used"}
            if config.model == "patchwork" else asdict(OptimizerConfig(
                learning_rate_q=config.learning_rate_q,
                learning_rate_supports=config.learning_rate_structure,
                learning_rate_stitches=config.learning_rate_structure,
                learning_rate_hyperparameters=config.learning_rate_hyperparameters,
                warmup_fraction=config.warmup_epochs / config.epochs)),
            "source_sha256": {str(p.relative_to(Path(__file__).resolve().parents[1])): file_checksum(p)
                              for p in sorted((Path(__file__).resolve().parents[1] / "src/pwgp").rglob("*.py"))},
        })
        visuals = output / "visuals"
        visuals.mkdir()
        started = time.perf_counter()
        model = build_model(config, split)
        initialization_seconds = time.perf_counter() - started
        write_json(output / "model_metadata.json", {
            "model_class": f"{type(model).__module__}.{type(model).__name__}",
            "package_version": importlib.metadata.version("generalized-patchwork-gp"),
            "kernel": "ARD RBF", "likelihood": "Gaussian",
            "inducing_positions_saved": save_inducing_positions and config.model != "patchwork",
            "partition_artifacts_saved": config.model == "patchwork",
            "training_observations_used": len(model.train_x) if config.model == "patchwork" else len(split["train"]),
            "training_points_policy": config.exact_training_points if config.model == "patchwork" else "all",
            "partition": config.exact_partition if config.model == "patchwork" else None,
            "actual_regions": model.patches if config.model == "patchwork" else None,
            "reference": "arXiv:2311.08752v1 (6)-(13), approved derived objective/prediction"
            if config.model == "prospar" else None,
        })
        if config.model == "gpw":
            np.savez_compressed(output / "initialization.npz",
                supports=model.initial_support_locations.cpu().numpy(),
                centers=model.initial_cluster_centers.cpu().numpy(), indices=model.source_initial_indices.cpu().numpy())
        if config.model == "patchwork":
            from experiments.exploratory_analysis import plot_partition

            np.savez_compressed(output / "training_points.npz", x=model.train_x.cpu().numpy(),
                               y=model.train_y.cpu().numpy(), indices=model.source_training_indices.cpu().numpy())
            np.savez_compressed(output / "partition.npz", bounds=model.region_bounds.cpu().numpy(),
                vertices=model.region_vertices.cpu().numpy(), offsets=model.region_offsets.cpu().numpy(),
                centers=model.region_centers.cpu().numpy(), labels=model.labels.cpu().numpy(),
                tree=model.partition_tree.cpu().numpy(),
                stitches=model.stitch_points.cpu().numpy(), coefficients=model.coefficients.cpu().numpy())
            plot_partition(model.train_x.cpu().numpy(), model.labels.cpu().numpy(),
                model.region_vertices.cpu().numpy(), model.region_offsets.cpu().numpy(),
                model.stitch_points.cpu().numpy(), destination=visuals / "partition.png")
        torch.save(model.state_dict(), output / "initial_model.pt")
        positions, position_epochs, parameter_history = [], [], []

        def snapshot(epoch, losses):
            write_json(output / "history.json", {"losses": losses})
            parameter_history.append({"epoch": epoch, **learned_parameters(model, config.model)})
            write_json(output / "hyperparameter_history.json", parameter_history)
            write_json(output / "status.json", {"state": "training", "epoch": epoch})
            if epoch == 0 or epoch % config.snapshot_every == 0 or epoch == config.epochs:
                if save_inducing_positions and config.model != "patchwork":
                    positions.append(supports(model, config.model).copy())
                    position_epochs.append(epoch)
                    np.savez_compressed(output / "inducing_positions.npz", epochs=position_epochs,
                                        supports=np.stack(positions))
                    plot_positions(positions[0], positions[-1], destination=visuals / "inducing_positions.png")
                if config.model == "gpw":
                    np.savez_compressed(output / f"stitches_epoch_{epoch}.npz",
                                        stitches=model.stitches().detach().cpu().numpy())
                plot_training(losses, destination=visuals / "training.png")
                plot_hyperparameters(parameter_history, destination=visuals / "hyperparameters.png")
                indices = split["validation"]
                mean, variance = predict(model, split["x"][indices], batch_size=config.prediction_batch_size)
                map_figure(split["raw_x"][indices],
                           {"Validation mean (standardized)": mean, "Observation SD": np.sqrt(variance)},
                           destination=visuals / "progress.png")
                torch.save(model.state_dict(), output / "checkpoint.pt")
                if on_snapshot is not None:
                    on_snapshot(output, epoch)

        snapshot(0, [])
        started = time.perf_counter()
        losses = train(model, split, config, snapshot)
        if device.type == "cuda":
            torch.cuda.synchronize(device)
        training_seconds = time.perf_counter() - started
        torch.save(model.state_dict(), output / "model.pt")
        write_json(output / "learned_parameters.json", learned_parameters(model, config.model))
        if config.model in ("gpw", "prospar"):
            weights = []
            with torch.no_grad():
                for batch in tqdm(split["x"][split["test"]].split(config.prediction_batch_size),
                                  desc="weights", unit="batch", leave=False):
                    query = batch.to(device)
                    value = model.fusion_weights(query) if config.model == "gpw" else model.conditional_terms(query)["weights"]
                    weights.append(value.cpu())
            weights = torch.cat(weights).numpy()
            np.savez_compressed(output / "fusion_weights.npz", indices=split["test"], weights=weights)
            map_figure(split["raw_x"][split["test"]],
                       {f"Expert {j + 1} weight": weights[:, j] for j in range(weights.shape[1])},
                       destination=visuals / "weights.png")
        all_scores, prediction_seconds = {}, 0.0
        for label in tqdm(("validation", "test"), desc="score", unit="split"):
            indices = split[label]
            started = time.perf_counter()
            mean, variance = predict(model, split["x"][indices], batch_size=config.prediction_batch_size)
            prediction_seconds += time.perf_counter() - started
            standardized = scores(split["y"][indices].numpy(), mean, variance)
            raw_mean = mean * split["target_std"] + split["target_mean"]
            raw_variance = variance * split["target_std"] ** 2
            all_scores[label] = {"standardized": standardized,
                                 "celsius": scores(split["raw_y"][indices], raw_mean, raw_variance)}
            np.savez_compressed(output / f"{label}_predictions.npz", indices=indices,
                                coordinates=split["raw_x"][indices], mean=raw_mean,
                                observation_variance=raw_variance, truth=split["raw_y"][indices])
            if label == "test":
                map_figure(split["raw_x"][indices], {
                    "Observed (C)": split["raw_y"][indices], "Predicted (C)": raw_mean,
                    "Absolute error (C)": np.abs(raw_mean - split["raw_y"][indices]),
                    "Observation SD (C)": np.sqrt(raw_variance)}, destination=visuals / "maps.png")
        metrics = {**all_scores["test"]["celsius"], "final_loss": losses[-1],
                   "initialization_seconds": initialization_seconds, "training_seconds": training_seconds,
                   "prediction_seconds": prediction_seconds, "test_points": len(split["test"]),
                   "peak_cuda_megabytes": torch.cuda.max_memory_allocated(device) / 2**20
                   if device.type == "cuda" else None}
        write_json(output / "all_scores.json", all_scores)
        write_json(output / "metrics.json", metrics)
        analyze_run(output)
        write_json(output / "status.json", {"state": "complete"})
        del snapshot
        model = None
        gc.collect()
        if device.type == "cuda":
            with torch.cuda.device(device):
                torch.cuda.empty_cache()
        return output


def run_comparison(data_config: OISSTConfig, runs: list[tuple[str, UKConfig]], *,
                   directory, data_root, source_provenance, source_zip,
                   on_snapshot=None, on_complete=None):
    output = Path(directory)
    output.mkdir(parents=True, exist_ok=False)
    with record_failures(output, status_key="state"):
        from experiments.run_selection import resolve_patchwork_references

        runs = resolve_patchwork_references(runs)
        if not runs or len({name for name, _ in runs}) != len(runs):
            raise ValueError("Comparison requires nonempty, uniquely named runs")
        if any(config.seed != data_config.seed for _, config in runs):
            raise ValueError("All runs must use the declared shared data seed")
        write_json(output / "data_config.json", asdict(data_config))
        write_json(output / "runs.json", [{"name": name, **asdict(config)} for name, config in runs])
        write_json(output / "source_provenance.json", source_provenance)
        (output / "source_snapshot.zip").write_bytes(source_zip)
        split, manifest = acquire(data_config, data_root=data_root)
        write_json(output / "data_manifest.json", manifest)
        write_json(output / "preprocessing.json", {key: split[key] for key in
                   ("target_mean", "target_std", "input_transform", "target_transform")})
        np.savez_compressed(output / "split.npz", **{key: split[key] for key in ("train", "validation", "test")})
        explore_dataset(split, directory=output / "exploratory")
        _run_models(data_config, runs, split, output, on_snapshot, on_complete)
        write_json(output / "status.json", {"state": "complete"})
    return output


def _run_models(data_config, runs, split, output, on_snapshot, on_complete):
    references = [config.exact_gpw_reference for _, config in runs
                  if config.model == "patchwork" and config.exact_training_points == "gpw_initial"]
    if references:
        from pwgp.initialization import hierarchical_initialization

        reference = references[0]
        if any(value != reference for value in references):
            raise ValueError("Matched baselines must use the same GPW initialization reference")
        if reference["inducing_points"] % reference["patches"]:
            raise ValueError("Reference GPW inducing budget must divide evenly across patches")
        torch.set_num_threads(reference["threads"])
        started = time.perf_counter()
        initial = hierarchical_initialization(split["x"][split["train"]], reference["patches"],
            reference["inducing_points"] // reference["patches"], seed=reference["seed"])
        write_json(output / "gpw_initialization.json", {"reference": reference,
                   "seconds": time.perf_counter() - started})
        np.savez_compressed(output / "gpw_initialization.npz", supports=initial["supports"].numpy(),
            centers=initial["centers"].numpy(), indices=split["train"][initial["indices"].numpy()])
        split = {**split, "gpw_initialization": initial, "gpw_initialization_reference": reference}
    summaries = []
    for index, (name, config) in enumerate(tqdm(runs, desc="compare:OISST", unit="model")):
        result = run_model(config, split, directory=output / f"{index:02d}_{config.model}",
                           save_inducing_positions=data_config.save_inducing_positions,
                           on_snapshot=on_snapshot)
        summaries.append({"model": name, "directory": str(result.resolve()),
                          **json.loads((result / "metrics.json").read_text())})
        write_json(output / "comparison.json", summaries)
        archive = output / f"{index:02d}_{config.model}.zip"
        with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as bundle:
            for path in sorted(output.iterdir()):
                if path.is_file() and (path.suffix in (".json", ".npz") or path.name == "source_snapshot.zip"):
                    bundle.write(path, path.name)
            for path in sorted(result.rglob("*")):
                if path.is_file():
                    bundle.write(path, path.relative_to(output))
        if on_complete is not None:
            on_complete(result, archive, summaries[-1])


def data_identity(config):
    return {key: value for key, value in asdict(config).items() if key != "save_inducing_positions"}


def prepare_experiment(data_config, *, directory, data_root, source_provenance, source_zip):
    """Acquire/prepare once and persist a checksum-verified reusable split."""
    output = Path(directory)
    output.mkdir(parents=True, exist_ok=False)
    with record_failures(output, status_key="state"):
        write_json(output / "data_config.json", asdict(data_config))
        write_json(output / "source_provenance.json", source_provenance)
        (output / "source_snapshot.zip").write_bytes(source_zip)
        split, manifest = acquire(data_config, data_root=data_root)
        write_json(output / "data_manifest.json", manifest)
        write_json(output / "preprocessing.json", {key: split[key] for key in
                   ("target_mean", "target_std", "input_transform", "target_transform")})
        np.savez_compressed(output / "split.npz", **{key: split[key] for key in ("train", "validation", "test")})
        np.savez_compressed(output / "prepared.npz", raw_x=split["raw_x"], raw_y=split["raw_y"],
                            x=split["x"].numpy(), y=split["y"].numpy())
        explore_dataset(split, directory=output / "exploratory")
        names = ("data_config.json", "data_manifest.json", "preprocessing.json", "split.npz", "prepared.npz",
                 "source_provenance.json", "source_snapshot.zip")
        write_json(output / "prepared_checksums.json", {name: file_checksum(output / name) for name in names})
        write_json(output / "status.json", {"state": "complete"})
    return output


def load_prepared(directory, *, data_config):
    """Load only the explicitly named preparation; never acquire or rebuild."""
    directory = Path(directory)
    if json.loads((directory / "status.json").read_text())["state"] != "complete":
        raise ValueError("Prepared data stage must be complete before reuse")
    checksums = json.loads((directory / "prepared_checksums.json").read_text())
    expected = {"data_config.json", "data_manifest.json", "preprocessing.json", "split.npz", "prepared.npz",
                "source_provenance.json", "source_snapshot.zip"}
    if set(checksums) != expected:
        raise ValueError("Prepared data checksum manifest must cover every required file")
    for name in tqdm(sorted(expected), desc="verify:prepared", unit="file", leave=False):
        if file_checksum(directory / name) != checksums[name]:
            raise ValueError(f"Prepared data checksum mismatch: {name}")
    stored = OISSTConfig(**json.loads((directory / "data_config.json").read_text()))
    if json.dumps(data_identity(stored), sort_keys=True) != json.dumps(data_identity(data_config), sort_keys=True):
        raise ValueError("Data settings changed; explicitly prepare a new dataset before training")
    preprocessing = json.loads((directory / "preprocessing.json").read_text())
    with np.load(directory / "prepared.npz", allow_pickle=False) as arrays:
        split = {key: arrays[key].copy() for key in ("raw_x", "raw_y")}
        split.update({key: torch.from_numpy(arrays[key].copy()) for key in ("x", "y")})
    with np.load(directory / "split.npz", allow_pickle=False) as groups:
        split.update({key: groups[key].copy() for key in ("train", "validation", "test")})
    split.update(preprocessing)
    return split


def run_prepared_comparison(data_config, runs, *, prepared_directory, directory,
                            source_provenance, source_zip, on_snapshot=None, on_complete=None):
    """Train exactly the selected models from scratch in a new batch directory."""
    output = Path(directory)
    output.mkdir(parents=True, exist_ok=False)
    with record_failures(output, status_key="state"):
        from experiments.run_selection import resolve_patchwork_references

        runs = resolve_patchwork_references(runs)
        write_json(output / "data_config.json", asdict(data_config))
        write_json(output / "runs.json", [{"name": name, **asdict(config)} for name, config in runs])
        write_json(output / "source_provenance.json", source_provenance)
        (output / "source_snapshot.zip").write_bytes(source_zip)
        if not runs or len({name for name, _ in runs}) != len(runs):
            raise ValueError("Comparison requires nonempty, uniquely named runs")
        if any(config.seed != data_config.seed for _, config in runs):
            raise ValueError("All runs must use the declared shared data seed")
        split = load_prepared(prepared_directory, data_config=data_config)
        for name in ("data_manifest.json", "preprocessing.json", "split.npz"):
            shutil.copy2(Path(prepared_directory) / name, output / name)
        write_json(output / "prepared_reference.json", {
            "directory": str(Path(prepared_directory).resolve()),
            "source_provenance": json.loads((Path(prepared_directory) / "source_provenance.json").read_text()),
            "checksums": json.loads((Path(prepared_directory) / "prepared_checksums.json").read_text())})
        _run_models(data_config, runs, split, output, on_snapshot, on_complete)
        write_json(output / "status.json", {"state": "complete"})
    return output


def completed_run_directories(directory):
    directory = Path(directory)
    if json.loads((directory / "status.json").read_text())["state"] != "complete":
        raise ValueError("Latest batch is not complete; select completed saved run paths explicitly")
    rows = json.loads((directory / "comparison.json").read_text())
    if not rows:
        raise ValueError("Completed batch must contain model results")
    paths = [Path(row["directory"]) for row in rows]
    for path in paths:
        if json.loads((path / "status.json").read_text())["state"] != "complete":
            raise ValueError(f"Selected model run is not complete: {path}")
    return paths


def archive_directory(directory, *, destination):
    directory, destination = Path(directory).resolve(), Path(destination).resolve()
    if not directory.is_dir():
        raise NotADirectoryError(directory)
    if destination.is_relative_to(directory):
        raise ValueError("Archive destination must be outside its source directory")
    destination.parent.mkdir(parents=True, exist_ok=True)
    paths = sorted(path for path in directory.rglob("*") if path.is_file())
    with zipfile.ZipFile(destination, "x", compression=zipfile.ZIP_DEFLATED) as bundle:
        for path in tqdm(paths, desc="archive", unit="file", leave=False):
            bundle.write(path, path.relative_to(directory))
    return destination
